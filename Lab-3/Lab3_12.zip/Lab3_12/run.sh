# !/bin/sh

python3 4-SAT.py

python3 12.py > output.txt

# ('A', 'B', 'c')
# ('A', 'c', 'd')
# ('B', 'C', 'd')
# ('B', 'a', 'c')
# ('a', 'c', 'd')

# [['A', 'B', 'C'], ['A', 'C', 'd'], ['B', 'a', 'd'], ['D', 'a', 'c'], ['a', 'b', 'd']]