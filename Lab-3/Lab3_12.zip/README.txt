Run the script as follows:

```
    $ ./run.sh
```

This will print the output in a new file called output.txt


## Additional Information:

4-SAT.py file is used to produce clauses. It is used in run.sh.

12.py is the main code which has implementation of algorithms over the input received from clauses.txt (produced when 4-SAT.py was run).