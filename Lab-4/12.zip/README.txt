Run the script as follows: (run.sh file needs executable : $ chmod +x run.sh)

```
    $ ./run.sh <input_file>
```

This will print the output in a new file called output.txt


## Additional Information:

12.py is the main code which has implementation of algorithms over the input received from Command Line Aruguments