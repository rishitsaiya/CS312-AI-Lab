python3 src/main.py test/input1

