Main code in src/main.cpp
Testcases in testcases/

Report - Lab2Group10Report.pdf

To run:

g++ src/main.cpp
./a.out testcases/input1