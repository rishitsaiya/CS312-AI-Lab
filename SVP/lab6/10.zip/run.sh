python3 ao.py $1
