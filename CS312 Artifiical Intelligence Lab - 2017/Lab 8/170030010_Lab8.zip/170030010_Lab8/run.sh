python3 lab8code.py input1.txt
