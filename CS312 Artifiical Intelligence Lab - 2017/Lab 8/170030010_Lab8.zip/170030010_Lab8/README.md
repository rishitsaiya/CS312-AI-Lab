Hi!

To run this code, run the following command
./run.sh <input-file>

Please follow the input file conditions to avoid getting erronous messages.
Remember to do the following things before running the shell script
1) chmod 777 run.sh
2) pip3 install numpy
3) pip3 install random
These modules are required to run the python program. 

by Mehul Bose. Sitting in Quarantine. April 2020.  
