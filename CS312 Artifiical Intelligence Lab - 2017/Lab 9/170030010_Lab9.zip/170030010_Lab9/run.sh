python3 Planning.py $1
