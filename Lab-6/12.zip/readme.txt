How to run code:

$ python 12.py

This mentioned command will work provided required packages and environment is setup. If want to check remotely, then open 12.ipynb in Google Colab/Jupyter Notebook and then run accordingly.