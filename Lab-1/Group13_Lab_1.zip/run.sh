g++ Group13_Lab_1.cpp

if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
fi

./a.out "$1"