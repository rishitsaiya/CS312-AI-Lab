g++ 180010015_180010027.cpp

if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
fi

./a.out "$1"