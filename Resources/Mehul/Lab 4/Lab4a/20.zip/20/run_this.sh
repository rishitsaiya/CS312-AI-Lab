python3 TSP.py $1
